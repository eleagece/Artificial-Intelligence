import java.util.ArrayList;
import java.util.Scanner;
import java.util.Random;

public class Principal
	{
	public static void main(String[] args) throws Exception 
		{
		/**
		 * FUERZA BRUTA
		 * -Con 'i' y 'j' recorremos todos los puntos del cuadrado.
		 * -Con 'k' creamos todos los c�rculos hasta el radio m�ximo que
		 * puede existir dentro del cuadrado que que es 'DIMENSION/2'.
		 * -Cada vez que encontremos una soluci�n mejor que la guardada
		 * la imprimimos.
		 * -Con 'fail' contamos los c�rculos generados que no fueron soluci�n.
		 * -Con 'success' contamos los c�rculos generados que fueron soluci�n.
		 */
/*		System.out.println("----------------------------------------------------");
		System.out.println("-- FUERZA BRUTA ------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema fuerzaBruta=new Problema("inicial.txt");
		int failFB=0; int successFB=0;
		for (int i=0; i<Problema.DIMENSION; i++)
			{
			for (int j=0; j<Problema.DIMENSION; j++)
				{
				for (int k=0; k<Problema.DIMENSION/2; k++)
					{
					Circulo c=new Circulo(i,j,k);
					if (fuerzaBruta.esMejorSolucion(c))
						{
						fuerzaBruta.setCirculoSol(c);
						System.out.println("Soluci�n parcial: "+c.toString());
						successFB++;
						}
					else
						failFB++;
					}
				}
			}
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN FUERZA BRUTA ---------------------");
		System.out.println("Soluci�n final: "+fuerzaBruta.getCirculoSol().toString()); int total=successFB+failFB;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+successFB);
		System.out.println("C�rculos no soluci�n: "+failFB);
		System.out.println("----------------------------------------------");
		System.out.println();
*/		
		/**
		 * ALEATORIO
		 * -Con 'i' creamos 'n' c�rculos aleatoriamente.
		 * -Cada vez que encontremos una soluci�n mejor que la guardada
		 * la imprimimos.
		 * -Con 'fail' contamos los c�rculos generados que no fueron soluci�n.
		 * -Con 'success' contamos los c�rculos generados que fueron soluci�n.
		 */
/*		System.out.println("----------------------------------------------------");
		System.out.println("-- ALEATORIO ---------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema aleatorio=new Problema("inicial.txt");
		int failRND=0; int successRND=0;
		Scanner inRND = new Scanner(System.in); 
	    System.out.printf("Introduce 'n': ");
	    int nRND = inRND.nextInt();
		for (int i=0; i<nRND; i++)
			{
			Circulo c=Circulo.random(Problema.DIMENSION);
			if (aleatorio.esMejorSolucion(c))
				{
				aleatorio.setCirculoSol(c);
				System.out.println("Soluci�n parcial: "+c.toString());
				successRND++;
				}
			else
				failRND++;
			}
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN ALEATORIO ------------------------");
		System.out.println("Soluci�n final: "+aleatorio.getCirculoSol().toString()); total=successRND+failRND;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+successRND);
		System.out.println("C�rculos no soluci�n: "+failRND);
		System.out.println("---------------------------------------------");
		System.out.println();
*/
		/**
		 * GEN�TICOS
		 * -Con 'n==0' creamos 38 c�rculos de poblaci�n inicial correspondientes a las cua-
		 * dr�culas 2x2=4 c�rculos, 3x3=9 c�rculos y 5x5=25 c�rculos. Con 'n>0' y par 
		 * creamos 'n' c�rculos aleatorios de poblaci�n inicial.
		 */
		System.out.println("----------------------------------------------------");
		System.out.println("-- GEN�TICOS ---------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema geneticos=new Problema("inicial.txt");
		int failGEN=0; int successGEN=0;
		Scanner inGEN = new Scanner(System.in); 
		System.out.printf("Introduce 'n': ");
	    int nGEN = inGEN.nextInt();
	    //////////////////////////
	    // 0. Poblaci�n inicial //
	    //////////////////////////
		ArrayList<Individuo> arrayPoblacionPadres = new ArrayList<Individuo>();
		ArrayList<Float> arrayProbCruce = new ArrayList<Float>();
		ArrayList<Individuo> arrayPoblacionHijos = new ArrayList<Individuo>();
		ArrayList<Individuo> arrayElite = new ArrayList<Individuo>();
		int generacion=0;
		int numIndividuosPadres=0;
		int numIndividuosHijos=0;
		float fitnessTotal=0;
		float tasaCruce=0.7f;
		float tasaMutacion=0.1f;
	    // Poblaci�n inicial de 38 individuos diversos
		if (nGEN==0)  
			{
			numIndividuosPadres=38;
			int r; int xInic; int yInic;
			Circulo c; Individuo ind;
			// C�rculos de cuadr�cula 2x2
			for (int i=1; i<=2; i++)
				{
				r=(Problema.DIMENSION/2)/2;
				xInic=r;
				yInic=r;
				for (int j=1; j<=2; j++)
					{
					c=new Circulo(xInic*i,yInic*j,r);
					ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			// C�rculos de cuadr�cula 3x3
			for (int i=1; i<=3; i++)
				{
				r=(Problema.DIMENSION/3)/2;
				xInic=r;
				yInic=r;
				for (int j=1; j<=3; j++)
					{
					c=new Circulo(xInic*i,yInic*j,r);
					ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			// C�rculos de cuadr�cula 5x5
			for (int i=1; i<=5; i++)
				{
				r=(Problema.DIMENSION/5)/2;
				xInic=r;
				yInic=r;
				for (int j=1; j<=5; j++)
					{
					c=new Circulo(xInic*i,yInic*j,r);
					ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			}
	    // Poblaci�n inicial aleatoria de 'n' elementos con 'n' par
		else if (nGEN>0 && nGEN%2==0)
			{
		    for (int i=0; i<nGEN; i++)
				{
		    	Circulo c=Circulo.random(Problema.DIMENSION);
		    	Individuo ind=new Individuo(c);
		    	arrayPoblacionPadres.add(ind);
		    	numIndividuosPadres++;
				}
			}
	    //////////////////////////////////////////////
	    // 1. Calcular fitness de toda la poblaci�n //
	    //////////////////////////////////////////////
		for (int i=0; i<numIndividuosPadres; i++)
			{
			arrayPoblacionPadres.get(i).calculateFitness(geneticos);
			fitnessTotal=fitnessTotal+arrayPoblacionPadres.get(i).getFitness();
			System.out.println(arrayPoblacionPadres.get(i).toString());
			}
		for (int i=0; i<numIndividuosPadres; i++)
			{
			if (i==0)
				arrayProbCruce.add(arrayPoblacionPadres.get(i).getFitness()/fitnessTotal);
			else
				arrayProbCruce.add((arrayPoblacionPadres.get(i).getFitness()/fitnessTotal)+arrayProbCruce.get(i-1));
			System.out.println(arrayProbCruce.get(i));
			}
		////////////////////////////////////////////////////
	    // 2. Crear poblaci�n nueva 'arrayPoblacionHijos' //
		////////////////////////////////////////////////////
	    while (numIndividuosPadres>numIndividuosHijos) 
	    	{
	    	Random rnd=new Random();  // Genera aleatorios entre 0 y 1 
	    	Individuo individuoA=null, individuoB=null;  // Individuos que se cruzar�n (o no)
	    	Individuo individuoAB=null, individuoBA=null;  // Individuos hijos de 'individuoA' e 'individuoB'
	    	///////////////
	    	// A. Ruleta //
	    	///////////////
	    	float randomA=rnd.nextFloat(); int posIndA=0;
	    	float randomB=rnd.nextFloat(); int posIndB=0;
	    	boolean encontrado=false;
	    	while (!encontrado)
	    		{
	    		if (arrayProbCruce.get(posIndA)<randomA)
	    			posIndA++;
	    		else
	    			{
	    			encontrado=true;
	    			individuoA=arrayPoblacionPadres.get(posIndA);
	    			}
	    		}
	    	encontrado=false;
	    	while (!encontrado)
	    		{
	    		if (arrayProbCruce.get(posIndB)<randomB)
	    			posIndB++;
	    		else
	    			{
	    			encontrado=true;
	    			individuoB=arrayPoblacionPadres.get(posIndB);
	    			}
	    		}
	    	//////////////
	    	// B. Cruce //
	    	//////////////
	    	float decideCruce=rnd.nextFloat();
	    	boolean hayCruce=false;
	    	if (decideCruce<tasaCruce)
	    		{
	    		int dondeCruza=(int)(rnd.nextFloat()*29);  // Genera n�meros de 0 y 28
	    		// Cruzar 'individuoA' e 'individuoB'
	    		String cromIndivAB_1=individuoA.getCromosoma().substring(0,dondeCruza+1);
	    		String cromIndivAB_2=individuoB.getCromosoma().substring(dondeCruza+1);
	    		String cromIndivAB=cromIndivAB_1+cromIndivAB_2;
	    		int lengthAB=cromIndivAB.length();
	    		String cromIndivBA_1=individuoB.getCromosoma().substring(0,dondeCruza+1);
	    		String cromIndivBA_2=individuoA.getCromosoma().substring(dondeCruza+1);
	    		String cromIndivBA=cromIndivAB_1+cromIndivAB_2;
	    		int lengthBA=cromIndivBA.length();
	    		individuoAB=new Individuo(cromIndivAB,0);
	    		individuoBA=new Individuo(cromIndivBA,0);
	    		hayCruce=true;
	    		}
	    	/////////////////
	    	// C. Mutaci�n //
	    	/////////////////
	    	if (hayCruce)
	    		{
	    		// Mutar o no
	    		// POR AHORA NO MUTAMOS, PASANDO
	    		// A�adir dos hijos a la poblaci�n nueva
	    		individuoAB.calculateFitness(geneticos);
	    		individuoBA.calculateFitness(geneticos);
	    		arrayPoblacionHijos.add(individuoAB);
	    		arrayPoblacionHijos.add(individuoBA);
	    		numIndividuosHijos=numIndividuosHijos+2;
	    		}
	    	}
		/////////////////////////////////////////////////////////
		// 3. Visualizar poblaci�n nueva 'arrayPoblacionHijos' //
		/////////////////////////////////////////////////////////
	    for (int i=0; i<numIndividuosPadres; i++)
			{
			System.out.println(arrayPoblacionHijos.get(i).toString());
			}
		/*
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN GEN�TICOS ------------------------");
		System.out.println("Soluci�n final: "+geneticos.getCirculoSol().toString()); total=success+fail;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+success);
		System.out.println("C�rculos no soluci�n: "+fail);
		System.out.println("---------------------------------------------");
		System.out.println();
		*/
		}
	}
