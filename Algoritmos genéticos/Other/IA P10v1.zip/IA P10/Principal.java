import java.util.ArrayList;
import java.util.Scanner;

public class Principal
	{
	public static void main(String[] args) throws Exception 
		{
		/**
		 * FUERZA BRUTA
		 * -Con 'i' y 'j' recorremos todos los puntos del cuadrado.
		 * -Con 'k' creamos todos los c�rculos hasta el radio m�ximo que
		 * puede existir dentro del cuadrado que que es 'DIMENSION/2'.
		 * -Cada vez que encontremos una soluci�n mejor que la guardada
		 * la imprimimos.
		 * -Con 'fail' contamos los c�rculos generados que no fueron soluci�n.
		 * -Con 'success' contamos los c�rculos generados que fueron soluci�n.
		 */
		System.out.println("----------------------------------------------------");
		System.out.println("-- FUERZA BRUTA ------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema fuerzaBruta=new Problema("inicial.txt");
		int fail=0;	int success=0;
		for (int i=0; i<Problema.DIMENSION; i++)
			{
			for (int j=0; j<Problema.DIMENSION; j++)
				{
				for (int k=0; k<Problema.DIMENSION/2; k++)
					{
					Circulo c=new Circulo(i,j,k);
					if (fuerzaBruta.esMejorSolucion(c))
						{
						fuerzaBruta.setCirculoSol(c);
						System.out.println("Soluci�n parcial: "+c.toString());
						success++;
						}
					else
						fail++;
					}
				}
			}
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN FUERZA BRUTA ---------------------");
		System.out.println("Soluci�n final: "+fuerzaBruta.getCirculoSol().toString()); int total=success+fail;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+success);
		System.out.println("C�rculos no soluci�n: "+fail);
		System.out.println("----------------------------------------------");
		System.out.println();
		
		/**
		 * ALEATORIO
		 * -Con 'i' creamos 'n' c�rculos aleatoriamente.
		 * -Cada vez que encontremos una soluci�n mejor que la guardada
		 * la imprimimos.
		 * -Con 'fail' contamos los c�rculos generados que no fueron soluci�n.
		 * -Con 'success' contamos los c�rculos generados que fueron soluci�n.
		 */
		System.out.println("----------------------------------------------------");
		System.out.println("-- ALEATORIO ---------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema aleatorio=new Problema("inicial.txt");
		fail=0;	success=0;
		Scanner in = new Scanner(System.in); 
	    System.out.printf("Introduce 'n': ");
	    int n = in.nextInt();
		for (int i=0; i<n; i++)
			{
			Circulo c=Circulo.random(Problema.DIMENSION);
			if (aleatorio.esMejorSolucion(c))
				{
				aleatorio.setCirculoSol(c);
				System.out.println("Soluci�n parcial: "+c.toString());
				success++;
				}
			else
				fail++;
			}
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN ALEATORIO ------------------------");
		System.out.println("Soluci�n final: "+aleatorio.getCirculoSol().toString()); total=success+fail;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+success);
		System.out.println("C�rculos no soluci�n: "+fail);
		System.out.println("---------------------------------------------");
		System.out.println();
		
		/**
		 * GEN�TICOS
		 * -Con 'n==0' creamos 38 c�rculos de poblaci�n inicial correspondientes a las cua-
		 * dr�culas 2x2=4 c�rculos, 3x3=9 c�rculos y 5x5=25 c�rculos. Con 'n>0' creamos 'n'
		 * c�rculos aleatorios de poblaci�n inicial.
		 */
		System.out.println("----------------------------------------------------");
		System.out.println("-- GEN�TICOS ---------------------------------------");
		System.out.println("----------------------------------------------------");
		Problema geneticos=new Problema("inicial.txt");
		fail=0; success=0;
		System.out.printf("Introduce 'n': ");
	    n = in.nextInt();
	    //////////////////////////
	    // 0. Poblaci�n inicial //
	    //////////////////////////
		ArrayList<Individuo> arrayPoblacionPadres = new ArrayList<Individuo>();
		ArrayList<Individuo> arrayPoblacionHijos = new ArrayList<Individuo>();
		ArrayList<Individuo> arrayElite = new ArrayList<Individuo>();
		int generacion=0;
		int numIndividuos=0;
		float fitnessTotal=0;
	    // Poblaci�n inicial de 38 individuos diversos
		if (n==0)  
			{
	    	numIndividuos=38;
			for (int i=1; i<=2; i++)
				{
				int r=(Problema.DIMENSION/2)/2;
				int xInic=r;
				int yInic=r;
				for (int j=1; j<=2; j++)
					{
					Circulo c=new Circulo(xInic*i,yInic*j,r);
					Individuo ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			for (int i=1; i<=3; i++)
				{
				int r=(Problema.DIMENSION/3)/2;
				int xInic=r;
				int yInic=r;
				for (int j=1; j<=3; j++)
					{
					Circulo c=new Circulo(xInic*i,yInic*j,r);
					Individuo ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			for (int i=1; i<=5; i++)
				{
				int r=(Problema.DIMENSION/5)/2;
				int xInic=r;
				int yInic=r;
				for (int j=1; j<=5; j++)
					{
					Circulo c=new Circulo(xInic*i,yInic*j,r);
					Individuo ind=new Individuo(c);
					arrayPoblacionPadres.add(ind);
					}
				}
			}
	    // Poblaci�n inicial aleatoria de 'n' elementos
		else if (n>0)
			{
		    for (int i=0; i<n; i++)
				{
		    	Circulo c=Circulo.random(Problema.DIMENSION);
		    	Individuo ind=new Individuo(c);
		    	arrayPoblacionPadres.add(ind);
				numIndividuos++;
				}
			}
	    //////////////////////////////////////////////
	    // 1. Calcular fitness de toda la poblaci�n //
	    //////////////////////////////////////////////
		for (int i=0; i<numIndividuos; i++)
			{
			arrayPoblacionPadres.get(i).calculateFitness();
			fitnessTotal=fitnessTotal+arrayPoblacionPadres.get(i).getFitness();
			}
		////////////////////////////////////////////////////
	    // 2. Crear poblaci�n nueva 'arrayPoblacionHijos' //
		////////////////////////////////////////////////////
	    // A. Cruzar por ruleta hasta tener una poblaci�n de 'n' nuevos
	    // B. Mutaci�n
		System.out.println("---------------------------------------------");
		System.out.println("-- RESUMEN GEN�TICOS ------------------------");
		System.out.println("Soluci�n final: "+geneticos.getCirculoSol().toString()); total=success+fail;
		System.out.println("C�rculos generados: "+total);
		System.out.println("C�rculos soluci�n: "+success);
		System.out.println("C�rculos no soluci�n: "+fail);
		System.out.println("---------------------------------------------");
		System.out.println();
		}
	}
